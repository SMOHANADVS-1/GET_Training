/**
 * 
 */
/**
 * 
 */
module AdvancedJavaProject {
	requires java.sql;
}