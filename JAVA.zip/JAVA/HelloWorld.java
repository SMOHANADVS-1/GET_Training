class HelloWorld
{
	public static void main(String[] args)
	{
		int a=10;
		int b=20;
		String org = "coforge";
		System.out.println("Hello World From Java Programming");
		System.out.println("My First Program in Java");
		
		int sum=a+b;
		System.out.println("The Sum Of two numbers is: "+ sum);
		System.out.println("Iam GET IN :"+org);
	}
}


