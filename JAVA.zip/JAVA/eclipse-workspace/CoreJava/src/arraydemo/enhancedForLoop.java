package arraydemo;

/**
 * Author  :Sola.Sri
 * Date    :Sep 2, 2025
 * Time    :9:58:53 AM  
 * project :CoreJava
*/

public class enhancedForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			// TODO Auto-generated method stub

			String array[] = {"Mohana", "Nikitha", "Keerthi", "Durga Rao","ram"};
			//for-each loop
			for(String x : array)
			{
				System.out.println(x);
			}
			
			 //for loop for same function
		/*	for(int i=0;i<array.length;i++)
			{
				System.out.println(array[i]);
			}*/


	}

}
