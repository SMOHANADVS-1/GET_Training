package basics;
/**
 * This is simple java program that prints "Hello,World!" to the console.
 * it demonstrates the basic structure of java application.
 * @version 1.0
 * using java doc Markup tags
 */
public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello, World! from Java");
		//sysout+ cntr+ Space
		System.out.println("She Sells Sea Shells at the Sea");
		
		int a = 10, b = 20, sum;
		
		sum= a + b;
		 
		System.out.println("Sum of a and b is: "+sum);
		

	}

}
