package basics;

import java.util.Scanner;

/**
 * Author  :Sola.Sri
 * Date    :Aug 30, 2025
 * Time    :9:34:26 AM  
 * project :CoreJava 
 * 
 * This program calculates the sum and average of set of numbers using Scanner Input.
*/

public class SumAverage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//variable declaration
		int number1,number2,number3,sum;
		float avg;
		Scanner scanner=new Scanner(System.in);
		
		
		System.out.println("Enter your organization : ");
		String org = scanner.nextLine();
		//take input		
		System.out.println("Enter 3 Numbers : ");
		number1 = scanner.nextInt();
		number2 = scanner.nextInt();
		number3 = scanner.nextInt();
		
		scanner.nextLine();//pause for the nextLine();
		System.out.println("Enter your Name : ");
		String name = scanner.nextLine();
		
		//process
		sum = number1+number2+number3;
		avg = (float) sum/3;
		
		//display output
		System.out.println("*************************************");
		System.out.println("The Sum of Three Numbers Is       : "+sum);
		System.out.println("The Average of Three Numbers Is   : "+ avg);
		System.out.println("Coded by "+name+" at" +org+" Training");
		System.out.println("*************************************");
		
		scanner.close();
		
		
		
		

	}

}
