package onlineshopping;

/**
 * Author  :Sola.Sri
 * Date    :Sep 6, 2025
 * Time    :12:02:50 PM  
 * project :CoreJava
*/
//Interface for Online Payment
interface OnlinePayment {
 void payOnline(double amount);
}