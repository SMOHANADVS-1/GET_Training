package onlineshopping;

/**
 * Author  :Sola.Sri
 * Date    :Sep 6, 2025
 * Time    :12:03:18 PM  
 * project :CoreJava
*/

//Interface for Discount
interface Discount {
 double applyDiscount(double amount);
}
