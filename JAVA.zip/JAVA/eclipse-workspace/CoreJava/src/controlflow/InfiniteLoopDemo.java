package controlflow;

/**
 * Author  :Sola.Sri
 * Date    :Sep 1, 2025
 * Time    :4:23:17 PM  
 * project :CoreJava
*/

public class InfiniteLoopDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Infinite Loops");

        /*while (true){
            System.out.println("Hello World");
        }*/

        for(;;){
            System.out.println("Hello World");
        }
	}

}
