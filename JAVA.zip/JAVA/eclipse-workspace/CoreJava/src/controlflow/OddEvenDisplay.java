package controlflow;

import java.util.Scanner;

/**
 * Author  :Sola.Sri
 * Date    :Sep 1, 2025
 * Time    :12:51:08 PM  
 * project :CoreJava
 *  Program to display Odd & Even Numbers between 1-10
 *
 * ODD  EVEN
 * ---  ----
 * 1    2
 * 3    4
 * 5    6
 * 7    8
 * 9    10
*/

public class OddEvenDisplay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number : ");
		int num = s.nextInt();
		int i=1;
		
		System.out.println("Odd\tEven");
		
		while(i<=num)
		{
			
			//System.out.print(i+"\t"+(i+1));
			//i=i+2;
			//System.out.println();
			if(i%2==1) {
			
			System.out.print(i);
			}
			else
			{
				System.out.println("\t" + i);
				
			}
			i=i+1;
			
			/*if(i%2==0)
			{
				System.out.println(i);
			}
			else
			{
				System.out.println();
			}*/
		}

	}

}
