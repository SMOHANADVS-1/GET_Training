package oopsdemo2;

/**
 * Author  :Sola.Sri
 * Date    :Sep 4, 2025
 * Time    :11:53:30 AM  
 * project :CoreJava
*/

public class AggregationDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Address ad1 = new Address("Bengaluru", "Karnataka", "India", 566016);
		Address ad2 = new Address("Guntur", "Andhra Pradesh", "India", 77777);
		Student s1 = new Student(101,"Mike",ad1);
		Student s2 = new Student(102,"Ravi",ad2);
		
		s1.display();
		s2.display();


	}

}
