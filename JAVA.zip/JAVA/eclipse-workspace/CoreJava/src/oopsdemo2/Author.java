package oopsdemo2;

/**
 * Author  :Sola.Sri
 * Date    :Sep 4, 2025
 * Time    :12:06:30 PM  
 * project :CoreJava
*/

public class Author {
	String authorName;
	int age;
	String place;
	public Author(String authorName, int age, String place) {
		this.authorName = authorName;
		this.age = age;
		this.place = place;
	}

}
