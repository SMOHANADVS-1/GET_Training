package oopsdemo2;

/**
 * Author  :Sola.Sri
 * Date    :Sep 4, 2025
 * Time    :11:49:33 AM  
 * project :CoreJava
*/
//Student has an Address - unidirectional Relationship

public class Student {
	
	int rollNo;
	String name;
	Address ad;//Entity Reference -Aggregation -has a relationship
	
  public Student(int rollNo, String name, Address ad) {
		this.rollNo = rollNo;
		this.name = name;
		this.ad = ad;
	}

  void display()
	{
		System.out.println("---------- Student Details ------------");
		System.out.println("Student Id   :"+rollNo );
		System.out.println("Student Name :"+name);
		
		System.out.println("Address: "+ad.city+" "+ad.state+" "+ad.country+" "+
		ad.pincode);
	}

}
