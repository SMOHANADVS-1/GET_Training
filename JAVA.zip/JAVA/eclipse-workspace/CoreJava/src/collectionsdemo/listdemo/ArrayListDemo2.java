package collectionsdemo.listdemo;

public class ArrayListDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PlayersList p1 = new PlayersList();
		
		p1.addPlayer();
		p1.display();
		p1.search();
		p1.extract();

	}

}
