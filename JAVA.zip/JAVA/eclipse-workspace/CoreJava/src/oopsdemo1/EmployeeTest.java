package oopsdemo1;

/**
 * Author  :Sola.Sri
 * Date    :Sep 2, 2025
 * Time    :4:42:23 PM  
 * project :CoreJava
*/
 // main class to test Employee class methods
public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//create objects e1,e2,e3 of Employee class
		Employee e1 = new Employee(); // invoke default constructor
		Employee e2 = new Employee(); 
		Employee e3 = new Employee(); 
		
		//invoke methods(Method Call
		e1.inputEmployeeDetails();//p1.eat();
		e1.calculateNetSalary();
		e1.displayEmployeeDetails();
		
		e2.inputEmployeeDetails();//p1.eat();
		e2.calculateNetSalary();
		e2.displayEmployeeDetails();

		e3.inputEmployeeDetails();//p1.eat();
		e3.calculateNetSalary();
		e3.displayEmployeeDetails();


	}

}
