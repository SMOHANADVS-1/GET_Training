package oopsdemo1;

/**
 * Author  :Sola.Sri
 * Date    :Sep 3, 2025
 * Time    :10:33:15 AM  
 * project :CoreJava
 * 
 * Java Program to implement instance class & main class in a Single file ---2nd way
*/
//instance class
class Lamp
{
	
	// stores the value for light
		  // true if light is on
		  // false if light is off
	    
	    
	boolean isOn;
	 //method to turn On the light
	void turnOn()
	{
		isOn = true;
		System.out.println("Light on? "+isOn);
	}
	
	 //method to turn Off the light
	
	void turnOff()
	{
		isOn = false;
		System.out.println("Light on? "+isOn);
	}


}

public class LampTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//create object led & halogen
		Lamp led = new Lamp();
		Lamp halogen =new  Lamp();
		
		//switch on led & halogen
		
		led.turnOn();
		halogen.turnOn();
		
		//switch off led & halogen
		led.turnOff();
		halogen.turnOff();

	}

}
