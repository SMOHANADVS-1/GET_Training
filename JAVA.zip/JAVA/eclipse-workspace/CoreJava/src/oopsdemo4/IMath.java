package oopsdemo4;

/**
 * Author  :Sola.Sri
 * Date    :Sep 5, 2025
 * Time    :4:35:56 PM  
 * project :CoreJava
*/

public interface IMath {
	// by default abstract methods
			public void add();
			public void sub();
			public void mul();
			public abstract void div();

}
