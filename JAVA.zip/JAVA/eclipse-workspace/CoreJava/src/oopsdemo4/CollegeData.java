package oopsdemo4;

/**
 * Author  :Sola.Sri
 * Date    :Sep 6, 2025
 * Time    :11:24:33 AM  
 * project :CoreJava
 */

public interface CollegeData {
	public void collegeDetail(); 
	public void studentData();


}

interface HostelData
{
	public void hostelDetail(); 
	public void studentRecord();
}


