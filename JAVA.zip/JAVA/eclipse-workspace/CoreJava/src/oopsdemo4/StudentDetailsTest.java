package oopsdemo4;

/**
 * Author  :Sola.Sri
 * Date    :Sep 6, 2025
 * Time    :11:37:02 AM  
 * project :CoreJava
*/

public class StudentDetailsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StudentDetails s1 = new StudentDetails();
		
		s1.collegeDetail();
		s1.studentData();
		
		s1.hostelDetail();
		s1.studentRecord();
		
		
	}

}
