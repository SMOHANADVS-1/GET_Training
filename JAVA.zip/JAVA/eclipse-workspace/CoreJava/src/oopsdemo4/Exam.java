package oopsdemo4;

/**
 * Author  :Sola.Sri
 * Date    :Sep 6, 2025
 * Time    :11:41:02 AM  
 * project :CoreJava
*/

public interface Exam {
	
	public abstract void percent_cal();

}
